<?php 

$val = '234';

print_r($val[0] + $val[1] + $val[2]);