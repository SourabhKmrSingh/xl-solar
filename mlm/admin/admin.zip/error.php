<?php
include_once("inc_config.php");
include_once("login_user_check.php");
?>
<!DOCTYPE html>
<html LANG="en">
<head>
<?php include_once("inc_title.php"); ?>
<?php include_once("inc_files.php"); ?>
</head>
<body>
<div ID="wrapper">
<?php include_once("inc_header.php"); ?>
<div ID="page-wrapper">
<div CLASS="container-fluid">
	<div CLASS="row">
		<div CLASS="col-lg-12">
			<h1 CLASS="page-header">ERROR!</h1>
		</div>
	</div>
	<br><br>
	<div class="row">
		<div class="col-sm-12">
			<p align="center">Please use right-side menu.<br />Or go to home page: <a href="home.php">check here</a>.
		</div>
	</div>
</div>
</div>
</div>
</body>
</html>